from abc import ABC, abstractmethod
try:
    from ..enums import BFIC
    from ..log import SiversLogger
except ImportError:
    from sivers_api.enums import BFIC
    from sivers_api.log import SiversLogger

_log = SiversLogger()

class SPIReq(ABC):
    """Base class for SPI implementations.

    Subclasses MUST define `compatible_bfic` as a non-empty list of supported BFIC values:

        class MySPI(SPIReq):
            compatible_bfic = [BFIC.EVK01, BFIC.EVK02]

    The compatibility check runs automatically on __init__ — no explicit call needed.
    """

    compatible_bfic: list[BFIC] = []

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        # Skip abstract subclasses — they'll be checked when concretely subclassed.
        if not getattr(cls, '__abstractmethods__', None):
            if not cls.compatible_bfic:
                raise TypeError(
                    f"{cls.__name__} must define 'compatible_bfic' as a non-empty list[BFIC]. "
                    f"Example:\n    compatible_bfic = [BFIC.EVK01, BFIC.EVK02]"
                )

    def __init__(self, csn: int, quiet: bool, bfic: BFIC):
        self.cs = csn
        self.quiet_mode = quiet
        self.bfic = self._check_compatibility(bfic)

    def _check_compatibility(self, bfic: BFIC):
        if bfic not in self.compatible_bfic:
            raise ValueError(f"Incompatible BFIC {bfic} for SPI implementation {type(self).__name__}")
        return bfic
    
    @abstractmethod
    def wr(self, chip_id:int, addr:int, data:int):
        _log.spi(f"spi{self.cs} wr  chip={chip_id} addr=0x{addr:04X} data=0x{data:04X}")
        self.last_wr = data

    @abstractmethod
    def rd(self, chip_id:int, addr:int) -> int:
        _log.spi(f"spi{self.cs} rd  chip={chip_id} addr=0x{addr:04X}")
        return self.last_wr

    @abstractmethod
    def wr_ext(self, chip_id:int, start_addr:int, data:list[int]):
        _log.spi(f"spi{self.cs} wr_ext chip={chip_id} start=0x{start_addr:04X} data={[f'0x{d:04X}' for d in data]}")

    @abstractmethod
    def rd_ext(self, chip_id:int, start_addr:int, length:int) -> list[int]:
        _log.spi(f"spi{self.cs} rd_ext chip={chip_id} start=0x{start_addr:04X} length={length}")
        return [self.last_wr] * length

    @abstractmethod
    def adc_capture(self, chip_id:int):
        _log.spi(f"spi{self.cs} adc_capture chip={chip_id}")

    @abstractmethod
    def reset(self):
        _log.spi(f"spi{self.cs} reset")

    @abstractmethod
    def verify_wr(self, chip_id:int, addr:int, data:int, retry:int=10):
        self.wr(chip_id, addr, data)
        self.rd(chip_id, addr)
        return data, 1

    @abstractmethod
    def verify_wr_ext(self, chip_id:int, start_addr:int, data:list[int], retry:int=10):
        self.wr_ext(chip_id, start_addr, data)
        self.rd_ext(chip_id, start_addr, len(data))
        return data, 1

    @abstractmethod
    def soft_reset(self, chip_id:int):
        _log.spi(f"spi{self.cs} soft_reset chip={chip_id}")

    @abstractmethod
    def init(self, speed):
        _log.spi(f"spi{self.cs} init speed={speed}")

    @abstractmethod
    def beam_up(self):
        _log.spi(f"spi{self.cs} beam_up")

    @abstractmethod
    def close(self):
        _log.spi(f"spi{self.cs} close")