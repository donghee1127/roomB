try:
    from ...enums import BFIC_TYPE, BFIC
    from ...spi.spi_ftdi import SPI_FTDI
    from ...spi.fake_spi import Fake_SPI
    from .base import Cloudchaser
except ImportError:
    from sivers_api.enums import BFIC_TYPE, BFIC
    from sivers_api.spi.spi_ftdi import SPI_FTDI
    from sivers_api.spi.fake_spi import Fake_SPI
    from sivers_api.chips.cloudchaser.base import Cloudchaser


class Stampede(Cloudchaser):
    def __init__(self, chip_id=0, quiet=True, spi_obj=None, fake_spi=False, fake_spi_cs_pin=0):
        if spi_obj is None:
            spi_cls = Fake_SPI if fake_spi else SPI_FTDI
            spi_obj = spi_cls(csn=fake_spi_cs_pin, bfic=BFIC.STAMPEDE)
        super().__init__(bfic=BFIC.STAMPEDE, bfic_type=BFIC_TYPE.TX, chip_id=chip_id, quiet=quiet, spi_obj=spi_obj)
