from enum import Enum

class BFIC(str, Enum):
    STAMPEDE = "STAMPEDE"
    BLUEWAY = "BLUEWAY"

class BFIC_TYPE(str, Enum):
    TX = "tx"
    RX = "rx"

class Beam(str, Enum):
    B0 = "b0" # H
    B1 = "b1" # V

class Channel(str, Enum):
    H0 = "h0"
    H1 = "h1"
    H2 = "h2"
    H3 = "h3"
    V0 = "v0"
    V1 = "v1"
    V2 = "v2"
    V3 = "v3"