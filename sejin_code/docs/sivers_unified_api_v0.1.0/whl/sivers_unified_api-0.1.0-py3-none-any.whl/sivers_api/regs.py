from __future__ import annotations
from collections import defaultdict
try:
    from .enums import BFIC_TYPE, BFIC
    from .spi.spi_spec import SPIReq
    from .registers import get_register_map
    from .log import SiversLogger
except ImportError:
    from sivers_api.enums import BFIC_TYPE
    from sivers_api.spi.spi_spec import SPIReq
    from registers import get_register_map
    from sivers_api.log import SiversLogger
import pandas as pd
from pathlib import Path
import copy

_log = SiversLogger()
# -----------------------------
# Field descriptor
# -----------------------------
class FieldValue(int):

    def __new__(cls, field: Field, obj: FieldBlock, value):
        inst = int.__new__(cls, value)
        inst._field = field
        inst._obj = obj
        return inst

    def _write(self, value):
        self._field.__set__(self._obj, value)
        return value

    # bit ops
    def __or__(self, other):
        return self._write(int(self) | other)
    
    def __ior__(self, other):
        return self.__or__(other)

    def __and__(self, other):
        return self._write(int(self) & other)

    def __xor__(self, other):
        return self._write(int(self) ^ other)
    
    def __invert__(self):
        return self._write(~int(self))

    # sweep helpers
    def __iadd__(self, other):
        return self._write(int(self) + other)

    def __isub__(self, other):
        return self._write(int(self) - other)
    
class Field:

    def __init__(self, segments):
        self.segments = segments
        self.width = sum(width for _, _, width in segments)

    def __get__(self, obj:FieldBlock, owner):

        if obj is None:
            return self

        dev = obj._parent._parent

        value = 0
        bitpos = 0

        for reg, bit, width in self.segments:
            reg = dev.regs._resolve(reg)
            regval = dev._regs[reg]

            mask = (1 << width) - 1
            part = (regval >> bit) & mask

            value |= part << bitpos
            bitpos += width

        return FieldValue(self, obj, value)

    def __set__(self, obj:FieldBlock, value):

        dev = obj._parent._parent

        bitpos = 0

        for reg, bit, width in self.segments:
            reg = dev.regs._resolve(reg)
            mask = (1 << width) - 1
            part = (value >> bitpos) & mask

            regval = dev._regs[reg]

            regval &= ~(mask << bit)
            regval |= part << bit

            dev._regs[reg] = regval
            dev._dirty.add(reg)

            bitpos += width
    
    def __len__(self, obj:FieldBlock):
        return self.width
    
    def clr(self, obj: FieldBlock, mask: int = 0):
        if mask == 0:
            mask = (1 << self.width) - 1

        mask &= (1 << self.width) - 1

        current = self.__get__(obj, type(obj))
        new_value = current & ~mask

        self.__set__(obj, new_value)

# -----------------------------
# Field container
# -----------------------------

class FieldBlock:

    def __init__(self, parent: "Fields"):
        self._parent = parent

    def __getattr__(self, name):

        raise AttributeError(
            f"Field '{name}' does not exist. Check spelling or case."
        )

# -----------------------------
# Register prox
# -----------------------------
class RegisterProxy:
    _auto_commit = True
    
    def __init__(self, parent: "Regs"):
        self._parent = parent

    @classmethod
    def set_auto_commit(cls, value: bool):
        cls._auto_commit = bool(value)

    @classmethod
    def get_auto_commit(cls) -> bool:
        return cls._auto_commit
    
    def _resolve(self, reg):

        # name lookup
        if isinstance(reg, str):

            if reg in self._parent.REGISTERS:
                return reg

            if reg.startswith("0x"):
                reg = int(reg, 16)

            else:
                raise KeyError(f"Register '{reg}' not found")

        # address lookup
        if isinstance(reg, int):

            if reg not in self._parent._addr_to_name:
                raise KeyError(f"Register address 0x{reg:04X} not found")

            return self._parent._addr_to_name[reg]

        raise TypeError("Register must be str or int")

    def _fields_in_reg(self, reg) -> set[str]:

        fields = set()

        for field_name, segments in self._parent.FIELDS.items():
            for r, _, _ in segments:
                if r == reg:
                    fields.add(field_name)

        return fields
    
    def __getitem__(self, reg):

        name = self._resolve(reg)

        return self._parent._regs[name]

    def __setitem__(self, reg, value):

        name = self._resolve(reg)

        self._parent._regs[name] = value
        self._parent._dirty.add(name)
    
    def commit(self):
        #Convenience method to commit after direct register access via regs[reg] = value
        self._parent.commit()
    
    def pending(self) -> set[str]:
        return self._parent.pending()
    
    def update(self):
        self._parent.read_full_addres_range()
    
    def wr(self, reg, value):
        """Write a register value (can write outside of REGISTERS via address or hex string)"""
        try:
            self.__setitem__(reg, value)
            if self.get_auto_commit():
                self.commit()
        except KeyError:
            if isinstance(reg, str) and reg.startswith("0x"):
                addr = int(reg, 16)
                self._parent.spi.wr(self._parent.chip_id, addr, value)
            elif isinstance(reg, int):
                self._parent.spi.wr(self._parent.chip_id, reg, value)
            else:
                raise TypeError("Register must be str or int")
    
    def rd(self, reg):
        """Read a register value (can read outside of REGISTERS via address or hex string)"""
        if isinstance(reg, str):
            addr = self._resolve(reg)
            self._parent._regs[addr] = self._parent.spi.rd(self._parent.chip_id, self._parent.REGISTERS[addr])
            return self.__getitem__(reg)
        elif isinstance(reg, int):
            try:
                name = self._resolve(reg)
                self._parent._regs[name] = self._parent.spi.rd(self._parent.chip_id, reg)
                return self.__getitem__(name)
            except KeyError:
                return self._parent.spi.rd(self._parent.chip_id, reg)
        else:
            raise TypeError("Register must be str or int")
    
    def set(self, reg, mask: int):
        """Set bits in a register (bitwise OR)"""
        try:
            old = self.__getitem__(reg)
            new_value = old | mask
            self.__setitem__(reg, new_value)
            if self.get_auto_commit():
                self.commit()
        except KeyError:
            if isinstance(reg, int):
                old = self._parent.spi.rd(self._parent.chip_id, reg)
                new_value = old | mask
                self._parent.spi.wr(self._parent.chip_id, reg, new_value)
            else:
                raise TypeError("Register must be str or int")
    
    def clr(self, reg, mask: int = 0):
        """Clears masked bits in a register immediately. If mask == 0 -> clear full register"""
        try:
            old = self.__getitem__(reg)
            if mask == 0:
                mask = (1 << 16) - 1
            new_value = old & ~mask
            self.__setitem__(reg, new_value)
            if self.get_auto_commit():
                self.commit()
        except KeyError:
            if isinstance(reg, int):
                old = self._parent.spi.rd(self._parent.chip_id, reg)
                if mask == 0:
                    mask = (1 << 16) - 1
                new_value = old & ~mask
                self._parent.spi.wr(self._parent.chip_id, reg, new_value)
            else:
                raise TypeError("Register must be str or int")
    
    def dump(self, start:int = 0x1000, stop:int = 0x1203+1, save_to_file:bool=False, filename:str="reg_dump.csv"):
        vals = []
        for name, addr in self._parent.REGISTERS.items():
            if addr < start:
                continue
            if addr > stop:
                break
            val = self._parent._regs[name]
            print(f"{name:20} 0x{addr:04X} : 0x{val:04X}")
            vals.append([name, addr, f"0x{addr:04X}", val, f"0x{val:04X}"])
            
        if save_to_file:
            dump_dir = Path("dumps")
            dump_dir.mkdir(exist_ok=True)
            df = pd.DataFrame(vals, columns=["Name", "Address", "Address_hex","Value","Value_hex"])
            final_filename = dump_dir / filename
            df.to_csv(final_filename.resolve(), index=False)
            print(f"Register dump saved to {final_filename.resolve()}")

# -----------------------------
# Device
# -----------------------------
class Fields:
    _auto_commit = True

    def __init__(self, parent: "Regs"):
        self._parent = parent
        self.fields = None

    @classmethod
    def set_auto_commit(cls, value: bool):
        cls._auto_commit = bool(value)

    @classmethod
    def get_auto_commit(cls) -> bool:
        return cls._auto_commit
    
    def __getitem__(self, key):
        f = self._get_field(key)  # validate field exists
        return f.__get__(self.fields, type(self.fields))
    
    def __setitem__(self, key, value):
        f = self._get_field(key)  # validate field exists
        f.__set__(self.fields, value)
    
    def _init(self):
        # create field container
        self.fields = FieldBlock(self)

        # attach descriptors
        for name, segments in self._parent.FIELDS.items():

            field = Field(segments)

            setattr(type(self.fields), name, field)
    
    def _regs_from_field(self, field: Field) -> set[str]:
        regs = set()
        for reg, _, _ in field.segments:
            regs.add(reg)
        return regs
    
    def _get_field(self, field: str) -> Field:
        if self.fields is None:
            raise RuntimeError("Regs.init() must be called before using fields")

        try:
            f: Field = getattr(type(self.fields), field)
        except AttributeError:

            valid = sorted(self._parent.FIELDS.keys())

            raise KeyError(
                f"Field '{field}' not found.\n"
                f"Valid fields: {', '.join(valid[:10])}..."
            )

        return f
    
    def commit(self):
        #Convenience method to commit after field writes via fields[field] = value
        self._parent.commit()
    
    def pending(self) -> set[str]:
        return self._parent.pending()
    
    def update(self, field:str=None) -> None:
        if field is not None:
            regs = self._regs_from_field(field)
            for reg in regs:
                self._parent.regs.rd(reg)
            return
        else:
            self._parent.read_full_addres_range()
    
    def wr(self, field: str, value: int):
        """Write a field value (same as fields.<field> = value)"""
        f = self._get_field(field)
        f.__set__(self.fields, value)
        if self.get_auto_commit():
            self.commit()
    
    def rd(self, field: str) -> int:
        """Read a field value updates pre reading and returns the value (same as value = fields.<field>)"""
        f = self._get_field(field)
        regs = self._regs_from_field(f)
        for reg in regs:
            self._parent.regs.rd(reg)
        return int(f.__get__(self.fields, type(self.fields)))
    
    def set(self, field: str, mask: int):
        """Set bits in a field (bitwise OR)"""
        f = self._get_field(field)
        current = f.__get__(self.fields, type(self.fields))
        new_value = current | mask
        f.__set__(self.fields, new_value)
        if self.get_auto_commit():
            self.commit()
    
    def clr(self, field: str, mask: int = 0):
        """Clears masked bits in a field immediately. If mask == 0 -> clear full field"""
        f = self._get_field(field)
        f.clr(self.fields, mask)
        if self.get_auto_commit():
            self.commit()
    
    def toggle(self, field: str, mask: int):
        f = self._get_field(field)
        current = f.__get__(self.fields, type(self.fields))
        new_value = current ^ mask
        f.__set__(self.fields, new_value)
        if self.get_auto_commit():
            self.commit()
    
    def step(self, field: str, delta: int):
        f = self._get_field(field)
        current = f.__get__(self.fields, type(self.fields))
        f.__set__(self.fields, current + delta)
        if self.get_auto_commit():
            self.commit()
    
    def set_many(self, **fields):
        """Sets mutliple regs"""
        for name, value in fields.items():
            f = self._get_field(name)
            f.__set__(self.fields, value)
        if self.get_auto_commit():
            self.commit()
    
    def dump(self, save_to_file:bool=False, filename:str="fields_dump.csv",update:bool=False):
        vals = []
        if update:
            self.update()
        for field in self._parent.FIELDS.keys():
            f = self._get_field(field)
            addrs_dec = list([s[0] for s in f.segments])
            addrs_hex = list([f"0x{addr:04X}" for addr in addrs_dec])
            val = f.__get__(self.fields, type(self.fields))
            vals.append([addrs_dec, addrs_hex, field, val, f"0x{val:04X}"])

        if save_to_file:
            dump_dir = Path("dumps")
            dump_dir.mkdir(exist_ok=True)
            df = pd.DataFrame(vals, columns=["Address[dec]", "Address[hex]", "Field", "Value[dec]", "Value[hex]"])
            final_filename = dump_dir / filename
            df.to_csv(final_filename.resolve(), index=False)
            print(f"Register dump saved to {final_filename.resolve()}")
        
class Regs:

    def __init__(self, spi: SPIReq, chip_id: int, bfic: BFIC, address_range:tuple[int,int]):
        self.spi = spi
        self.chip_id = chip_id
        self.bfic = bfic
        self.REGISTERS, self.FIELDS, self.EFUSE_INSTRUCTIONS = get_register_map(bfic)
        self._reset_register_state = {r: 0 for r in self.REGISTERS}
        self._regs = {r: 0 for r in self.REGISTERS}
        self._addr_to_name = {addr: name for name, addr in self.REGISTERS.items()}
        self._dirty = set()
        self.regs = RegisterProxy(self)
        self.fields = Fields(self)
        self.address_range = address_range
        self.init()

    # -------------------------
    def read_map_range(self):
        for name, addr in self.REGISTERS.items():
            self._regs[name] = self.spi.rd(self.chip_id, addr)

    def read_full_addres_range(self):
        for addr in range(self.address_range[0], self.address_range[1]+1):
            reg = self._addr_to_name.get(addr)
            if reg is not None:
                self._regs[reg] = self.spi.rd(self.chip_id, addr)
        
    
    def read_range(self, start_addr, stop_addr):
        for addr in range(start_addr, stop_addr+1):
            reg = self._addr_to_name.get(addr)
            if reg is not None:
                self._regs[reg] = self.spi.rd(self.chip_id, addr)
    
    def _load_reset(self):
        self._regs.update(self._reset_register_state)
    
    def _set_reset(self):
        self._reset_register_state.update(self._regs)
    
    def pending(self) -> set[str]:
        return self._dirty.copy()
    
    def commit(self, verify=False, retry_count:int=10):
        
        if not self._dirty:
            return

        # convert register names → sorted addresses
        dirty_regs = sorted(self._dirty, key=lambda r: self.REGISTERS[r])

        bursts = []
        current = [dirty_regs[0]]

        for r in dirty_regs[1:]:

            prev_addr = self.REGISTERS[current[-1]]
            addr = self.REGISTERS[r]

            if addr == prev_addr + 1:
                current.append(r)
            else:
                bursts.append(current)
                current = [r]

        bursts.append(current)

        _log.debug(f"Committing {len(dirty_regs)} register(s) in {len(bursts)} burst(s) for chip_id={self.chip_id}")

        # perform writes
        for group in bursts:

            start_addr = self.REGISTERS[group[0]]
            values = [self._regs[r] for r in group]

            if len(values) == 1:
                if verify:
                    dat, count = self.spi.verify_wr(self.chip_id, start_addr, values[0], retry_count)
                    if dat != values[0] and count >= retry_count:
                        raise ValueError(f"Spi write to {hex(start_addr)}; {hex(values[0])} failed verification...")
                else:
                    self.spi.wr(self.chip_id, start_addr, values[0])
            else:
                if verify:
                    dat, count = self.spi.verify_wr_ext(self.chip_id, start_addr, values, retry_count)
                    if dat != values[0] and count >= retry_count:
                        raise ValueError(f"Spi write to {hex(start_addr)}; [{[hex(val) for val in values]}] failed verification...")
                else:
                    self.spi.wr_ext(self.chip_id, start_addr, values)

        self._dirty.clear()
            
    def init(self):
        # create field container
        self.fields._init()

