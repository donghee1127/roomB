
try:
    from ....regs import Regs
    from ....enums import Beam, Channel, BFIC_TYPE
except ImportError:
    from sivers_api.regs import Regs
    from sivers_api.enums import Beam, Channel, BFIC_TYPE
    
class Bias:

    def __init__(self, regs: Regs):
        self.regs = regs

    def _ac(self) -> bool:
        return self.regs.regs.get_auto_commit()

    def enable_center(self):
        self.regs.regs.wr("center_control", 3)

    def enable_beam(self, beam: Beam):
        if beam == Beam.B0:
            b_idx = 0
        elif beam == Beam.B1:
            b_idx = 1
        self.regs.fields[f"center_bias_beam{b_idx}_en"] = 1
        if self._ac():
            self.regs.commit()

    def enable_channel(self, channel: Channel):
        channel_idx = int(channel.value[-1])
        self.regs.fields[f"ch{channel_idx}_bias_en"] = 1
        if self._ac():
            self.regs.commit()

    def disable_center(self):
        self.regs.fields["centerbias_en"] = 0
        self.regs.fields["centermirror_en"] = 0
        if self._ac():
            self.regs.commit()

    def disable_beam(self, beam: Beam=None):
        if beam == Beam.B0:
            b_idx = 0
        elif beam == Beam.B1:
            b_idx = 1
        elif beam is None:
            b_idx = None

        if b_idx is None:
            self.regs.fields["center_bias_beam0_en"] = 0
            self.regs.fields["center_bias_beam1_en"] = 0
        else:
            self.regs.fields[f"center_bias_beam{b_idx}_en"] = 0

        if self._ac():
            self.regs.commit()

    def disable_channel(self, channel: Channel):
        channel_idx = int(channel.value[-1])
        self.regs.fields[f"ch{channel_idx}_bias_en"] = 0
        if self._ac():
            self.regs.commit()