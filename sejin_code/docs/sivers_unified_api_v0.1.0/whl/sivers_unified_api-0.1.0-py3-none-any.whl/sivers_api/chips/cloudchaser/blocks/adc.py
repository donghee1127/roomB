try:
    from ...regs import Regs
except ImportError:
    from sivers_api.regs import Regs
from typing import Literal, Type, Union
import numpy as np
from enum import Enum

type PDSource = Literal["H0", "H1", "H2", "H3", "V0", "V1", "V2", "V3", "B0", "B1"]
type TestSource = Literal["Dctest_EN center", "Dctest_ENBGR", "Dctest_GC", "Dctest_mode"]
type TempC = float
type Volt = float
type Raw = int
type Dec = float
type dB = float

class Conversions(Enum):
    Raw = "Raw"
    Dec = "Dec"
    Volt = "Volt"
    dB = "dB"
    TempC = "TempC"

class Source(Enum):
    PD = "PD"
    TEST = "TEST"
    TEMP = "TEMP"

class ADC:
    def __init__(self, regs:Regs):
        self.regs = regs
        self.spi = self.regs.spi
        self._conversions = {
            "Raw"   : {"conv": Conversions.Raw,    "some conversion": 1},
            "Dec"   : {"conv": Conversions.Dec,    "some conversion": 1},
            "Volt"  : {"conv": Conversions.Volt,   "some conversion": 1},
            "dB"    : {"conv": Conversions.dB,     "some conversion": 1},
            "TempC" : {"conv": Conversions.TempC,  "some conversion": 1},
        }
        self.pd_conv = self._conversions["Raw"] # default to raw, can be changed by user
        self.test_conv = self._conversions["Volt"] # default to Volt, can be changed by user
        self.temp_conv = self._conversions["TempC"] # default to TempC, can be changed by user
        
        self.src = {
            "PD_H0" : {"field" : "PD_ADC_H0",    "addr" : 0x1024, "start_bit" : 0, "stop_bit" : 7, "enable" : {"addr" : 0x101C, "value": 0x1, "bit" : 0}, "GC": {"addr": 0x1034, "start_bit": 0, "stop_bit": 1, "default": 0x0},"source":None},
            "PD_H1" : {"field" : "PD_ADC_H1",    "addr" : 0x1025, "start_bit" : 0, "stop_bit" : 7, "enable" : {"addr" : 0x101D, "value": 0x1, "bit" : 0}, "GC": {"addr": 0x1035, "start_bit": 0, "stop_bit": 1, "default": 0x0},"source":None},
            "PD_H2" : {"field" : "PD_ADC_H2",    "addr" : 0x1026, "start_bit" : 0, "stop_bit" : 7, "enable" : {"addr" : 0x101E, "value": 0x1, "bit" : 0}, "GC": {"addr": 0x1036, "start_bit": 0, "stop_bit": 1, "default": 0x0},"source":None},
            "PD_H3" : {"field" : "PD_ADC_H3",    "addr" : 0x1027, "start_bit" : 0, "stop_bit" : 7, "enable" : {"addr" : 0x101F, "value": 0x1, "bit" : 0}, "GC": {"addr": 0x1037, "start_bit": 0, "stop_bit": 1, "default": 0x0},"source":None},
            "PD_V0" : {"field" : "PD_ADC_V0",    "addr" : 0x1028, "start_bit" : 0, "stop_bit" : 7, "enable" : {"addr" : 0x101C, "value": 0x1, "bit" : 2}, "GC": {"addr": 0x1034, "start_bit": 2, "stop_bit": 3, "default": 0x0},"source":None},
            "PD_V1" : {"field" : "PD_ADC_V1",    "addr" : 0x1029, "start_bit" : 0, "stop_bit" : 7, "enable" : {"addr" : 0x101D, "value": 0x1, "bit" : 2}, "GC": {"addr": 0x1035, "start_bit": 2, "stop_bit": 3, "default": 0x0},"source":None},
            "PD_V2" : {"field" : "PD_ADC_V2",    "addr" : 0x102a, "start_bit" : 0, "stop_bit" : 7, "enable" : {"addr" : 0x101E, "value": 0x1, "bit" : 2}, "GC": {"addr": 0x1036, "start_bit": 2, "stop_bit": 3, "default": 0x0},"source":None},
            "PD_V3" : {"field" : "PD_ADC_V3",    "addr" : 0x102b, "start_bit" : 0, "stop_bit" : 7, "enable" : {"addr" : 0x101F, "value": 0x1, "bit" : 2}, "GC": {"addr": 0x1037, "start_bit": 2, "stop_bit": 3, "default": 0x0},"source":None},
            "PD_B0" : {"field" : "PD_ADC_PORT0", "addr" : 0x102c, "start_bit" : 0, "stop_bit" : 7, "enable" : {"addr" : 0x1032, "value": 0x5, "bit" : 0}, "GC": {"addr": 0x1033, "start_bit": 0, "stop_bit": 7, "default": 0x0},"source":None}, #TODO Check start bit and stop bit for port 1/2 since in the same register same for enables
            "PD_B1" : {"field" : "PD_ADC_PORT1", "addr" : 0x102d, "start_bit" : 0, "stop_bit" : 7, "enable" : {"addr" : 0x1032, "value": 0x5, "bit" : 3}, "GC": {"addr": 0x1033, "start_bit": 0, "stop_bit": 7, "default": 0x0},"source":None},
            "TEMP"  : {"field" : "Temp_ADC",     "addr" : 0x1023, "start_bit" : 0, "stop_bit" : 7, "enable" : {"addr" : 0x1022, "value": 0x1, "bit" : 8}, "GC": None, "source":None},
            "TEST"  : {"field" : "TEST_ADC",     "addr" : 0x1030, "start_bit" : 0, "stop_bit" : 7, "enable" : {"addr" : 0x1100, "value": 0x1, "bit" : 5}, "GC": None, "source":{"Dctest_EN center":{"addr":0x1031, "start": 0, "stop": 9}, "Dctest_ENBGR":{"addr":0x1031, "start": 10, "stop": 10}, "Dctest_GC": {"addr":0x1031, "start": 11, "stop": 12}, "Dctest_mode":{"addr":0x1031, "start": 13, "stop": 15}}},
        }
    
    def set_conv(self, source:Union[str, Source], conv:Union[str, Conversions]):
        """Set the conversion type for a given source"""
        if isinstance(source, str):
            source = Source(source)
        if isinstance(conv, str):
            conv = Conversions(conv)
            
        if source == Source.PD:
            self.pd_conv = self._conversions[conv.value]
        elif source == Source.TEST:
            self.test_conv = self._conversions[conv.value]
        elif source == Source.TEMP:
            self.temp_conv = self._conversions[conv.value]
    
    def get_conv(self, source:Union[str, Source]) -> dict:
        """Get the conversion type for a given source"""
        if isinstance(source, str):
            source = Source(source)
            
        if source == Source.PD:
            return self.pd_conv
        elif source == Source.TEST:
            return self.test_conv
        elif source == Source.TEMP:
            return self.temp_conv
    
    def convert(self, conversion_options:dict, value:Raw) -> Union[Volt, Dec, dB, TempC, Raw]:
        """Convert raw ADC value to physical units based on the conversion options"""
        # TODO: Implement conversion logic based on the conversion type returns raw value for now since conversion formulas are not yet defined
        if conversion_options["conv"] == Conversions.Raw:
            return value
        elif conversion_options["conv"] == Conversions.Dec:
            return value # placeholder
        elif conversion_options["conv"] == Conversions.Volt:
            return value # placeholder
        elif conversion_options["conv"] == Conversions.dB:
            return value # placeholder
        elif conversion_options["conv"] == Conversions.TempC:
            return value # placeholder
        else:
            return value # Fallback to raw if conversion type is unrecognized

    def _get_mask(self, start_bit:int, stop_bit:int) -> int:
        return ((1 << (stop_bit - start_bit + 1)) - 1) << start_bit

    def get_data(self, src:str) -> Raw:
        print("ADC FUNCTINALITY NOT IMPLEMENTED/TESTED YET, MAY RETURN INCORRECT VALUES") # TODO Remove this warning once functionality is fully implemented and tested
        self.spi.adc_capture(self.regs.chip_id)
        return self.spi.rd(self.regs.chip_id, self.src[src]["addr"]) & self._get_mask(self.src[src]["start_bit"], self.src[src]["stop_bit"])
    
    def get_temp(self) -> TempC:
        """Get temperature reading in degrees Celsius from ADC"""
        self.set_conv(Source.TEMP, Conversions.TempC)
        #TODO Temp sensor conversion formula needed and implementation
        return self.convert(self.get_conv(Source.TEMP), self.get_data("TEMP"))
    
    def set_test_source(self, source:TestSource, value:int):
        """Set the source for the TEST_ADC"""
        if source not in self.src["TEST"]["source"]:
            raise KeyError(f"Invalid test source {source} choose from: {list(self.src['TEST']['source'].keys())}")
        
        addr = self.src["TEST"]["source"][source]["addr"]
        start_bit = self.src["TEST"]["source"][source]["start"]
        stop_bit = self.src["TEST"]["source"][source]["stop"]
        
        mask = self._get_mask(start_bit, stop_bit)
        value_shifted = (value << start_bit) & mask
        current_value = self.regs.regs[addr]
        new_value = (current_value & ~mask) | value_shifted
        
        self.regs.regs[addr] = new_value
        self.regs.commit()
        
    def get_test_data(self) -> Union[Volt, Dec, Raw]:
        """Get raw ADC data from TEST_ADC"""
        return self.convert(self.get_conv(Source.TEST), self.get_data("TEST"))
    
    def read_all_pd(self, reps:int=1) -> dict[str, Union[Raw, Dec, Volt, dB]]:
        """Read all power detector ADCs and return a dict of source: value pairs"""
        # Enable all PDs
        data = {}
        for src in self.src:
            data[src] = []
            if src.startswith("PD_H") or src.startswith("PD_V"):
                self.regs.regs[self.src[src]["enable"]["addr"]] |= (self.src[src]["enable"]["value"] << self.src[src]["enable"]["bit"])
            elif src.startswith("PD_B"):
                self.regs.regs[self.src[src]["enable"]["addr"]] |= (self.src[src]["enable"]["value"] << self.src[src]["enable"]["bit"])
        self.regs.commit()
        
        # Take the requested number of readings for each enabled PD and store
        for _ in range(reps):
            for src in self.src.keys():
                if src.startswith("PD_H") or src.startswith("PD_V") or src.startswith("PD_B"):
                    data[src].append(self.get_data(src))
        
        # Disable all PDs after reading
        for src in self.src.keys():
            if src.startswith("PD_H") or src.startswith("PD_V"):
                self.regs.regs[self.src[src]["enable"]["addr"]] &= ~(self.src[src]["enable"]["value"] << self.src[src]["enable"]["bit"])
            elif src.startswith("PD_B"):
                self.regs.regs[self.src[src]["enable"]["addr"]] &= ~(self.src[src]["enable"]["value"] << self.src[src]["enable"]["bit"])
        self.regs.commit()
        
        # Return the median value for each source if multiple readings were taken, otherwise return the single reading
        ret = {}
        for src in data:
            if len(data[src]) == 1:
                ret[src] = self.convert(self.get_conv(Source.PD), data[src][0])
            else:
                ret[src] = self.convert(self.get_conv(Source.PD), np.median(data[src]))
        return ret

    def get_pd_data(self, source: PDSource="H0", reps:int=1) -> Union[Volt, Dec, Raw, dB]:
        """Get raw ADC data for a given source, if reps > 1 returns the median of the readings"""
        # Enable the PD on the provided source
        src = f"PD_{source}"
        self.regs.regs[self.src[src]["enable"]["addr"]] |= (self.src[src]["enable"]["value"] << self.src[src]["enable"]["bit"])
        self.regs.commit()
        
        # Take the requested number of readings and store
        vals = []
        for _ in range(reps):
            vals.append(self.get_data(src))
            
        # Disable the PD on the provided source
        self.regs.regs[self.src[src]["enable"]["addr"]] &= ~(self.src[src]["enable"]["value"] << self.src[src]["enable"]["bit"])
        self.regs.commit()
        
        # Return the median value if multiple readings were taken, otherwise return the single reading
        if reps == 1:
            return self.convert(self.get_conv(Source.PD), vals[0])
        else:
            return self.convert(self.get_conv(Source.PD), np.median(vals))