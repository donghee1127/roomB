from __future__ import annotations
from contextlib import contextmanager
from typing import TYPE_CHECKING, Union, Optional, Any
if TYPE_CHECKING:
    from ..base import Cloudchaser
try:
    from ....enums import Beam, Channel, BFIC_TYPE
except ImportError:
    from sivers_api.enums import Beam, Channel, BFIC_TYPE


class PathSpec:
    def __init__(self, _parent: Cloudchaser, bfic_type: BFIC_TYPE):
        self.bfic_type = bfic_type
        self._parent = _parent
        self._active_paths: dict[Beam, list[Channel]] = {Beam.B0: [], Beam.B1: []}

    @property
    def active(self) -> dict[Beam, list[Channel]]:
        return {beam: list(channels) for beam, channels in self._active_paths.items()}

    @contextmanager
    def _batched(self):
        regs = self._parent._regs
        if not regs.regs.get_auto_commit():
            yield
            return
        saved_f = regs.fields.get_auto_commit()
        saved_r = regs.regs.get_auto_commit()
        regs.fields.set_auto_commit(False)
        regs.regs.set_auto_commit(False)
        try:
            yield
        finally:
            regs.commit()
            regs.fields.set_auto_commit(saved_f)
            regs.regs.set_auto_commit(saved_r)

    def single(self, channel: Union[Channel, str], beam: Union[Beam, str]) -> None:
        """Enable routing for channel -> beam. Additive: existing active paths are preserved."""
        channel, beam = self._parse(channel, beam)
        with self._batched():
            if channel not in self._active_paths[beam]:
                if not self._any_active():
                    self._parent.center.enable()
                if not self._active_paths[beam]:
                    self._parent.center.enable(beam)
                    self._parent.bias.enable_beam(beam)
                self._active_paths[beam].append(channel)
                self._set_path(channel, self._beams_for(channel))

    def enable(self, channels: list, beam: Union[Beam, str]) -> None:
        """Enable routing for a list of channels to a single beam."""
        beam = self._parse_beam(beam)
        with self._batched():
            for ch in channels:
                self.single(self._parse_channel(ch), beam)

    def enable_all(self, pol: str, beam: Union[Beam, str]) -> None:
        """Enable all 4 channels of the given polarization to a beam."""
        pol = pol.lower()
        if pol not in ("h", "v"):
            raise ValueError("Polarization must be 'h' or 'v'")
        with self._batched():
            self.enable([Channel(f"{pol}{i}") for i in range(4)], beam)

    def disable_all(self) -> None:
        """Disable all active paths and power down all hardware."""
        with self._batched():
            all_channels = {c for channels in self._active_paths.values() for c in channels}
            self._active_paths = {Beam.B0: [], Beam.B1: []}
            for channel in all_channels:
                self._set_path(channel, [])
            for beam in (Beam.B0, Beam.B1):
                self._disable_beam(beam)
            self._parent.center.disable()
            self._parent.bias.disable_center()

    def clear(self) -> None:
        """Clear internal routing state without touching hardware. Call after a chip reset."""
        self._active_paths = {Beam.B0: [], Beam.B1: []}

    def disable_single(self, channel: Optional[Union[Channel, str]] = None, beam: Optional[Union[Beam, str]] = None) -> None:
        """Disable routing.
        channel only  -> disable channel across all beams (updates split to []).
        beam only     -> disable beam entirely; updates split for any channel that was on it.
        channel+beam  -> disable channel from all beams, then disable the specified beam entirely.
        """
        if channel is None and beam is None:
            raise ValueError("At least one of channel or beam must be specified.")
        channel = self._parse_channel(channel) if channel is not None else None
        beam = self._parse_beam(beam) if beam is not None else None

        with self._batched():
            if channel is not None and beam is None:
                for b in self._active_paths:
                    self._active_paths[b] = [c for c in self._active_paths[b] if c != channel]
                self._set_path(channel, [])
                if not self._any_active():
                    self._parent.center.disable()
                    self._parent.bias.disable_center()

            elif channel is None and beam is not None:
                for c in list(self._active_paths[beam]):
                    self._active_paths[beam] = [x for x in self._active_paths[beam] if x != c]
                    self._set_path(c, self._beams_for(c))
                self._active_paths[beam] = []
                self._disable_beam(beam)
                if not self._any_active():
                    self._parent.center.disable()
                    self._parent.bias.disable_center()

            else:
                for b in self._active_paths:
                    self._active_paths[b] = [c for c in self._active_paths[b] if c != channel]
                self._set_path(channel, [])
                for c in list(self._active_paths[beam]):
                    self._set_path(c, self._beams_for(c))
                self._active_paths[beam] = []
                self._disable_beam(beam)
                if not self._any_active():
                    self._parent.center.disable()
                    self._parent.bias.disable_center()

    def _set_path(self, channel: Channel, beams: list[Beam]) -> None:
        """Push the complete routing state for channel down to the quad hardware.

        beams is the target beam list for this channel after the state update has
        already been written to active_paths.  The opposite-polarisation channel at
        the same index is consulted so the shared enables bits are only cleared when
        *neither* polarisation needs a beam anymore.
        """
        pol = channel.value[0]
        channel_idx = int(channel.value[1])
        quad = self._parent.quad[channel_idx]

        other_pol = "v" if pol == "h" else "h"
        other_channel = Channel(f"{other_pol}{channel_idx}")
        other_beams = self._beams_for(other_channel)
        all_active_beams = list(set(beams) | set(other_beams))

        quad.configure(pol, beams, all_active_beams)

        if beams:
            self._parent.bias.enable_channel(channel)
        else:
            self._parent.bias.disable_channel(channel)

    def _disable_beam(self, beam: Beam) -> None:
        """Disable the beam hardware entirely."""
        self._parent.center.disable(beam)
        self._parent.bias.disable_beam(beam)

    def _any_active(self) -> bool:
        return any(self._active_paths.values())

    def _beams_for(self, channel: Channel) -> list[Beam]:
        return [b for b, channels in self._active_paths.items() if channel in channels]

    @staticmethod
    def _parse(channel: Any, beam: Any) -> tuple[Channel, Beam]:
        return PathSpec._parse_channel(channel), PathSpec._parse_beam(beam)

    @staticmethod
    def _parse_channel(channel: Any) -> Channel:
        if isinstance(channel, Channel):
            return channel
        if isinstance(channel, str):
            return Channel(channel.lower())
        raise TypeError(f"Expected Channel or str, got {type(channel).__name__}")

    @staticmethod
    def _parse_beam(beam: Any) -> Beam:
        if isinstance(beam, Beam):
            return beam
        if isinstance(beam, str):
            return Beam(beam.lower())
        raise TypeError(f"Expected Beam or str, got {type(beam).__name__}")
