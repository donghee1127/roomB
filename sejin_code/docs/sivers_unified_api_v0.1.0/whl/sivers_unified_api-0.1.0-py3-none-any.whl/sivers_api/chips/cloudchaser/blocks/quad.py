
try:
    from ....regs import Regs
    from ....enums import Beam, Channel, BFIC_TYPE
except ImportError:
    from sivers_api.regs import Regs
    from sivers_api.enums import Beam, Channel, BFIC_TYPE

class Quad:
    def __init__(self, channel: int, regs: Regs):
        self.channel = channel
        self.regs = regs

    def _ac(self) -> bool:
        return self.regs.regs.get_auto_commit()
    
    def configure(self, pol: str, beams: list, all_active_beams: list) -> None:
        """Set the complete routing state for one polarization on this channel.

        pol:              'h' or 'v' — the polarization being configured.
        beams:            beams this pol should connect to.
        all_active_beams: union of beams needed by either pol at this channel index.
                          Because of a chip bug the h/v enables bits are shared, so the
                          enables must stay set as long as *any* pol uses a beam.
        """
        pol = pol.lower()
        if pol not in ("h", "v"):
            raise ValueError("Polarization must be 'h' or 'v'")

        for beam in (Beam.B0, Beam.B1):
            b_idx = int(beam.value[1])
            if beam in all_active_beams:
                self.regs.fields[f"ch{self.channel}_h_enables"] |= 1 << b_idx
                self.regs.fields[f"ch{self.channel}_v_enables"] |= 1 << b_idx
            else:
                self.regs.fields[f"ch{self.channel}_h_enables"] &= ~(1 << b_idx)
                self.regs.fields[f"ch{self.channel}_v_enables"] &= ~(1 << b_idx)

        self.regs.fields[f"ch{self.channel}_{pol}_pwrdn"] = 0x7 if beams else 0
        self.regs.fields[f"ch{self.channel}_pwrdn_override"] = 1 if all_active_beams else 0

        if self._ac():
            self.regs.commit()

    def enable(self, pol: str, beam: Beam):
        if beam == Beam.B0:
            b_idx = 0
        elif beam == Beam.B1:
            b_idx = 1

        pol = pol.lower()
        if pol not in ["h", "v"]:
            raise ValueError("Polarization must be 'h' or 'v'")

        # Both h and v have to be enabled on splitter/combiner because of a bug in chip
        self.regs.fields[f"ch{self.channel}_h_enables"] |= 1 << b_idx
        self.regs.fields[f"ch{self.channel}_v_enables"] |= 1 << b_idx

        self.regs.fields[f"ch{self.channel}_{pol}_pwrdn"] = 0x7

        self.regs.fields[f"ch{self.channel}_pwrdn_override"] = 1

        if self._ac():
            self.regs.commit()

    def disable(self, pol: str, beam: Beam):
        if beam == Beam.B0:
            b_idx = 0
        elif beam == Beam.B1:
            b_idx = 1

        pol = pol.lower()
        if pol not in ["h", "v"]:
            raise ValueError("Polarization must be 'h' or 'v'")

        # Both h and v have to be disabled on splitter/combiner because of a bug in chip
        self.regs.fields[f"ch{self.channel}_h_enables"] &= ~(1 << b_idx)
        self.regs.fields[f"ch{self.channel}_v_enables"] &= ~(1 << b_idx)

        self.regs.fields[f"ch{self.channel}_{pol}_pwrdn"] = 0

        self.regs.fields[f"ch{self.channel}_pwrdn_override"] = 0

        if self._ac():
            self.regs.commit()