import logging
from pathlib import Path

SPI_LEVEL = 5
logging.addLevelName(SPI_LEVEL, "SPI")


class SiversLogger:
    """Central logger for the sivers_api package.

    A singleton wrapper around Python's logging.Logger. All chip instances
    share the same underlying logger, so a single call to level() or
    add_handler() applies package-wide.

    Usage:
        chip.cfg.logger.level("DEBUG")
        chip.cfg.logger.add_handler(SiversLogger.file_handler("run.log"))
    """

    _instance: "SiversLogger | None" = None
    _LOGGER_NAME = "sivers_api"

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._init_logger()
        return cls._instance

    def _init_logger(self):
        self._log = logging.getLogger(self._LOGGER_NAME)
        self._log.propagate = False
        if not self._log.handlers:
            handler = logging.StreamHandler()
            handler.setFormatter(logging.Formatter("[%(levelname)s] %(message)s"))
            self._log.addHandler(handler)
        self._log.setLevel(logging.INFO)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def level(self, level: str) -> None:
        """Set the log level. Accepts DEBUG, INFO, WARNING, ERROR, CRITICAL."""
        self._log.setLevel(level.upper())

    def add_handler(self, handler: logging.Handler) -> None:
        """Add any logging.Handler instance (file, socket, etc.)."""
        self._log.addHandler(handler)

    def remove_handler(self, handler: logging.Handler) -> None:
        """Remove a previously added handler."""
        self._log.removeHandler(handler)

    def clear_handlers(self) -> None:
        """Remove all handlers."""
        self._log.handlers.clear()

    def set_formatter(self, fmt: str, datefmt: str | None = None) -> None:
        """Apply a format string to all current handlers."""
        formatter = logging.Formatter(fmt, datefmt=datefmt)
        for handler in self._log.handlers:
            handler.setFormatter(formatter)

    # ------------------------------------------------------------------
    # Convenience handler factories
    # ------------------------------------------------------------------

    @staticmethod
    def file_handler(path: str | Path, level: str = "DEBUG") -> logging.FileHandler:
        """Create a file handler that appends to *path*."""
        handler = logging.FileHandler(path)
        handler.setLevel(level.upper())
        handler.setFormatter(
            logging.Formatter("%(asctime)s [%(levelname)s] %(message)s",
                              datefmt="%Y-%m-%d %H:%M:%S")
        )
        return handler

    # ------------------------------------------------------------------
    # Internal use — call these from within the package
    # ------------------------------------------------------------------

    def spi(self, msg: str, *args, **kwargs) -> None:
        self._log.log(SPI_LEVEL, msg, *args, **kwargs)

    def debug(self, msg: str, *args, **kwargs) -> None:
        self._log.debug(msg, *args, **kwargs)

    def info(self, msg: str, *args, **kwargs) -> None:
        self._log.info(msg, *args, **kwargs)

    def warning(self, msg: str, *args, **kwargs) -> None:
        self._log.warning(msg, *args, **kwargs)

    def error(self, msg: str, *args, **kwargs) -> None:
        self._log.error(msg, *args, **kwargs)
