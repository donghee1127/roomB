
from typing import Union
try:
    from .spi.spi_spec import SPIReq
    from .regs import Regs
    from .enums import BFIC_TYPE, BFIC
    from .log import SiversLogger
except ImportError:
    from sivers_api.spi.spi_spec import SPIReq
    from sivers_api.regs import Regs
    from sivers_api.enums import BFIC_TYPE, BFIC
    from sivers_api.log import SiversLogger

class Sivers_BFIC:
    def __init__(self, bfic:Union[BFIC, str], bfic_type:Union[BFIC_TYPE, str], chip_id:int, quiet:bool=True, spi_obj:SPIReq=None, address_range:tuple[int,int]=(0x1000, 0x1201)):
        if not isinstance(bfic, (str, BFIC)):
            raise TypeError(f"Invalid type for bfic: {type(bfic)} expected 'str' or 'BFIC'")
        if isinstance(bfic, str):
            self.bfic = BFIC(bfic)
        elif isinstance(bfic, BFIC):
            self.bfic = bfic
        if not isinstance(bfic_type, (str, BFIC_TYPE)):
            raise TypeError(f"Invalid type for bfic_type: {type(bfic_type)} expected 'str' or 'BFIC_TYPE'")
        if isinstance(bfic_type, str):
            self.bfic_type = BFIC_TYPE(bfic_type)
        elif isinstance(bfic_type, BFIC_TYPE):
            self.bfic_type = bfic_type
            
        self.chip_id = chip_id
        self.spi = spi_obj
        self._regs = Regs(self.spi, self.chip_id, self.bfic, address_range)
        self.regs = self._regs.regs
        self.fields = self._regs.fields
        self.cfg = Config(self)
        self._regs.init()

    def commit(self):
        """Write all pending register changes to the device."""
        self._regs.commit()
    
    def pending(self) -> set[str]:
        """Return a set of pending register and field names that have been modified but not yet committed to the device."""
        return self._regs.pending()
    
    def load_efuse(self):
        """Load eFuse values into the device. Override in subclass to determine revision and call _execute_efuse_instructions."""
        pass

    def _execute_efuse_instructions(self, revision: str):
        """Execute EFUSE_INSTRUCTIONS for the given revision string in Instruction ID order.

        Instruction types:
          R     — read from HW, store in value_store[value_id]
          W     — write value_store[value_id]
          RCLR  — read from HW into value_store[value_id], then clear
          CLR   — clear
          FIXED — write fixed_value

        Append -REG in the register map Type column to operate on the full register
        (via address) instead of just the named field.
        """
        instructions = self._regs.EFUSE_INSTRUCTIONS.get(revision)
        if not instructions:
            self.cfg.logger.warning(f"No eFuse instructions found for revision '{revision}' on {self.bfic.value} chip_id={self.chip_id}.")
            return

        value_store: dict[str, int] = {}
        saved_fields_ac = self.fields.get_auto_commit()
        saved_regs_ac = self.regs.get_auto_commit()
        self.fields.set_auto_commit(True)
        self.regs.set_auto_commit(True)

        try:
            for instr_id in sorted(instructions.keys()):
                step = instructions[instr_id]
                field = step["field"]
                addr = step["addr"]
                instr_type = step["instruction"]
                value_id: str = step.get("value_id")
                fixed_value = step.get("fixed_value")
                full_reg: bool = step.get("full_reg", False)

                if full_reg:
                    if instr_type == "R":
                        value_store[value_id] = self.regs.rd(addr)
                    elif instr_type == "W":
                        if value_id not in value_store:
                            raise ValueError(f"eFuse instruction {instr_id}: value_id '{value_id}' has not been read yet")
                        self.regs.wr(addr, value_store[value_id])
                    elif instr_type == "RCLR":
                        value_store[value_id] = self.regs.rd(addr)
                        self.regs.clr(addr)
                    elif instr_type == "CLR":
                        self.regs.clr(addr)
                    elif instr_type == "FIXED":
                        if fixed_value is None:
                            raise ValueError(f"eFuse instruction {instr_id}: FIXED type requires a fixed_value")
                        self.regs.wr(addr, fixed_value)
                else:
                    if instr_type == "R":
                        value_store[value_id] = self.fields.rd(field)
                    elif instr_type == "W":
                        if value_id not in value_store:
                            raise ValueError(f"eFuse instruction {instr_id}: value_id '{value_id}' has not been read yet")
                        self.fields.wr(field, value_store[value_id])
                    elif instr_type == "RCLR":
                        value_store[value_id] = self.fields.rd(field)
                        self.fields.clr(field)
                    elif instr_type == "CLR":
                        self.fields.clr(field)
                    elif instr_type == "FIXED":
                        if fixed_value is None:
                            raise ValueError(f"eFuse instruction {instr_id}: FIXED type requires a fixed_value")
                        self.fields.wr(field, fixed_value)
        finally:
            self.fields.set_auto_commit(saved_fields_ac)
            self.regs.set_auto_commit(saved_regs_ac)
        self.cfg.logger.info(f"Applied {len(instructions)} eFuse instruction(s) for revision '{revision}' on {self.bfic.value} chip_id={self.chip_id}")

    #TODO - add option to only load certain blocks (e.g. only core, or only beam table etc.) for faster initialization
    def init(self, blocks:Union[str, list[str]]=["all"]):
        self.spi.reset()
        #read all regs loaded from map to populate local cache
        if "all" in blocks:
            self._regs.read_full_addres_range()
        else:
            self._regs.read_map_range()
        # Sets current register values as the reset default so when calling self.reset() it will load this state instead of having to re read from the device again.
        self._regs._set_reset()
        self.load_efuse()
        self.cfg.logger.info(f"Chip initialized: {self.bfic.value} chip_id={self.chip_id}")

    def reset(self):
        self.spi.reset()
        # load reset default values into local cache
        self._regs._load_reset()
        self.load_efuse()
        self.cfg.logger.info(f"Chip reset: {self.bfic.value} chip_id={self.chip_id}")

class Config:
    def __init__(self, _parent:Sivers_BFIC):
        self._parent = _parent
        self.logger = SiversLogger()

    def set_auto_commit(self, value:bool):
        if not isinstance(value, bool):
            raise TypeError(f"Invalid type for auto_commit value: {type(value)} expected 'bool'")
        self._parent.regs.set_auto_commit(value)
        self._parent.fields.set_auto_commit(value)