import pandas as pd
try:
    from .enums import BFIC_TYPE, BFIC
    from .log import SiversLogger
except ImportError:
    from sivers_api.enums import BFIC_TYPE, BFIC
    from sivers_api.log import SiversLogger
from typing import Union
from pathlib import Path

_log = SiversLogger()

def get_register_map(bfic: Union[BFIC, str]) -> tuple[dict[str:int], dict[str:list[tuple[int, int, int]]]]:
    bfic = BFIC(bfic) if isinstance(bfic, str) else bfic
    if bfic in RegisterParser.loaded_maps:
        return RegisterParser.loaded_maps[bfic]
    return RegisterParser.load_map(bfic)

class RegisterParser:
    loaded_maps = {}
    @staticmethod
    def list_register_maps()-> list[Path]:
        map_dir = Path(__file__).parent / "data" / "register_maps"

        if not map_dir.exists():
            raise FileNotFoundError(f"register maps directory not found: {map_dir}")
        map_files = list(map_dir.glob("*.xlsx"))
        if not map_files:
            raise FileNotFoundError(f"No register map files found in directory: {map_dir}")
        return map_files
    
    @staticmethod
    def get_map_for_bfic(bfic: BFIC) -> Path:
        for map_file in RegisterParser.list_register_maps():
            if bfic.value.lower() in map_file.stem.lower():
                return map_file
        raise ValueError(f"No register map found for BFIC: {bfic}")
    
    @staticmethod
    def load_map(bfic: Union[BFIC, str]):
        REGISTERS = {}
        FIELDS = {}
        EFUSE_INSTRUCTIONS = {}
        bfic = BFIC(bfic) if isinstance(bfic, str) else bfic
        mapname = RegisterParser.get_map_for_bfic(bfic)
        macro_sheet = "MACRO"
        efuse_sheet = "EFUSE_INSTRUCTIONS"
        excepts = ["Setup"]
        all_sheets = pd.ExcelFile(mapname).sheet_names
        sheets_to_parse = [s for s in all_sheets if s not in excepts]
        xls = pd.read_excel(mapname, sheet_name=sheets_to_parse, skiprows=2)
        for sheet_name, df in xls.items():
            # Clean columns
            df.columns = df.columns.str.strip()
        
            # Drop empty rows
            df = df.dropna(subset=["Address", "Reg Name", "Field Name"])
            
            for _, row in df.iterrows():
                addr = int(row["Address"])
                reg = str(row["Reg Name"]).strip()
                field = str(row["Field Name"]).strip()
                field = field.replace(" ", "_").lower()
                if field.lower() in ["reserved", "resv", "n/a", "na"]:
                    continue
                
                lsb = int(row["Lsb"])
                msb = int(row["Msb"])
                try:
                    length = int(row["Bit Length"])
                except ValueError as e:
                    if pd.isna(row["Bit Length"]):
                        length = msb - lsb + 1
                    else:
                        raise ValueError(f"Invalid bit length for field {field} in sheet {sheet_name}: {row['Bit Length']}") from e

                if lsb < 0 or msb < 0 or length <= 0:
                    raise ValueError(f"Invalid bit positions for field {field} in sheet {sheet_name}: lsb={lsb}, msb={msb}, length={length}")
                if msb < lsb:
                    raise ValueError(f"Msb cannot be less than lsb for field {field} in sheet {sheet_name}: lsb={lsb}, msb={msb}")
                if msb - lsb + 1 != length:
                    raise ValueError(f"Bit length does not match msb-lsb+1 for field {field} in sheet {sheet_name}: lsb={lsb}, msb={msb}, length={length}")
                if sheet_name == efuse_sheet:
                    rev = str(row["Revision Name"]).strip() if not pd.isna(row["Revision Name"]) else None
                    instruction = str(row["Type"]).strip().upper() if not pd.isna(row["Type"]) else None
                    raw_vid = row.get("Value ID")
                    if raw_vid is not None and not pd.isna(raw_vid):
                        s = str(raw_vid).strip()
                        try:
                            value_id = str(int(float(s)))
                        except (ValueError, TypeError):
                            value_id = s
                    else:
                        value_id = None
                    raw_iid = row["Instruction ID"]
                    instruction_id = int(float(str(raw_iid).strip())) if not pd.isna(raw_iid) else None
                    raw_fv = row.get("Fixed Value")
                    fixed_value = int(float(raw_fv)) if raw_fv is not None and not pd.isna(raw_fv) else None
                    if instruction.endswith("-REG"):
                        instruction, _ = instruction.split("-REG", 1)
                        full_reg = True
                        instruction = instruction.strip()
                    else:
                        full_reg = False
                    if instruction not in ["R", "W", "RCLR", "CLR", "FIXED"]:
                        raise ValueError(f"Invalid instruction type for EFUSE instruction in sheet {sheet_name} at address 0x{addr:04X}: {instruction}")
                    if not rev:
                        raise ValueError(f"Revision name is required for EFUSE instruction in sheet {sheet_name} at address 0x{addr:04X}")
                    if instruction_id is None:
                        raise ValueError(f"Instruction ID is required for EFUSE instruction in sheet {sheet_name} at address 0x{addr:04X}")
                    EFUSE_INSTRUCTIONS.setdefault(rev, {})[instruction_id] = {
                        "field": field,
                        "addr": addr,
                        "instruction": instruction,
                        "value_id": value_id,
                        "fixed_value": fixed_value,
                        "full_reg": full_reg
                    }
                    continue
                # ---- REGISTERS ----
                if reg not in REGISTERS:
                    REGISTERS[reg] = addr
                elif REGISTERS[reg] != addr:
                    raise ValueError(
                        f"Duplicate register name '{reg}' in sheet '{sheet_name}': "
                        f"already mapped to 0x{REGISTERS[reg]:04X}, now seen at 0x{addr:04X}. "
                        f"Fix the register map — duplicate register names break address resolution."
                    )
        
                # ---- FIELDS ----
                # Only store first occurrence warning for duplicate fields here since there should be none on these sheets.
                # Macro sheets (multi addr fields) are parsed from a separete sheet but should not have duplicate field names either.
                if field in FIELDS:
                    if sheet_name == macro_sheet:
                        FIELDS.setdefault(field, []).append((addr, lsb, length))
                    else:
                        raise ValueError(f"Duplicate field name found: {field} in sheet {sheet_name}")
                elif field not in FIELDS:
                    FIELDS[field] = [(addr, lsb, length)]
                else:
                    _log.warning(f"Duplicate field name detected: '{field}' in sheet '{sheet_name}' — check register map.")
        efuse_count = sum(len(v) for v in EFUSE_INSTRUCTIONS.values())
        _log.info(f"Register map loaded for {bfic.value} from '{mapname.name}': {len(REGISTERS)} registers, {len(FIELDS)} fields, {efuse_count} eFuse instructions")
        RegisterParser.loaded_maps[bfic] = (REGISTERS, FIELDS, EFUSE_INSTRUCTIONS)
        return REGISTERS, FIELDS, EFUSE_INSTRUCTIONS