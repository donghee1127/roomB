try:
    from ..chips.cloudchaser import cloudchaser_cli
    from .spi_spec import SPIReq
    from ..enums import BFIC
    from ..log import SiversLogger
except ImportError:
    from sivers_api.chips.cloudchaser import cloudchaser_cli
    from sivers_api.spi.spi_spec import SPIReq
    from sivers_api.enums import BFIC
    from sivers_api.log import SiversLogger
import time

_log = SiversLogger()

class SPI_FTDI(SPIReq):
    compatible_bfic = [BFIC.STAMPEDE, BFIC.BLUEWAY]

    def __init__(self, csn=0, quiet=True, bfic: BFIC = None):
        self._spi = cloudchaser_cli.CloudchaserCli()
        super().__init__(csn, quiet, bfic)
        cloudchaser_cli.connect(self._spi)
        if quiet:
            self._spi.onecmd('printout off')
    
    @property
    def spi(self):
        return self._spi
    
    def wr(self, chip_id:int, addr:int, data:int):
        _log.spi(f"spi{self.cs} wr  chip={chip_id} addr=0x{addr:04X} data=0x{data:04X}")
        self.spi.Cloudchaser_drv.spi_write(chip_id, addr, data)

    def rd(self, chip_id:int, addr:int) -> int:
        r = self.spi.Cloudchaser_drv.spi_read(chip_id, addr)
        _log.spi(f"spi{self.cs} rd  chip={chip_id} addr=0x{addr:04X} -> 0x{r:04X}")
        return r

    def wr_ext(self, chip_id:int, start_addr:int, data:list[int]):
        _log.spi(f"spi{self.cs} wr_ext chip={chip_id} start=0x{start_addr:04X} data={[f'0x{d:04X}' for d in data]}")
        self.spi.Cloudchaser_drv.spi_write_ex(chip_id, start_addr, data)

    def rd_ext(self, chip_id:int, start_addr:int, length:int) -> int:
        r = self.spi.Cloudchaser_drv.spi_read_ex(chip_id, start_addr, length)
        _log.spi(f"spi{self.cs} rd_ext chip={chip_id} start=0x{start_addr:04X} length={length} -> {[f'0x{d:04X}' for d in r]}")
        return r

    def adc_capture(self, chip_id:int):
        _log.spi(f"spi{self.cs} adc_capture chip={chip_id}")
        self.spi.Cloudchaser_drv.spi_adc_capture(chip_id)

    def rdwr(self, chip_id:int, addr:int, data:int) -> int:
        rb = self.rd(chip_id, addr)
        self.wr(chip_id, addr, data | rb)
        return rb

    def wrrd(self, chip_id:int, addr:int, data:int) -> int:
        self.wr(chip_id, addr, data)
        rb = self.rd(chip_id, addr)
        return rb

    def verify_wr(self, chip_id:int, addr:int, data:int, retry:int = 10):
        idx = 0
        rb = None
        while (idx < retry) and (rb != data):
            rb = self.wrrd(chip_id, addr, data)
            idx += 1
            time.sleep(0.0001)
        return rb, idx

    def verify_wr_ext(self, chip_id:int, start_addr:int, data:list[int], retry:int = 10):
        idx = 0
        rb = None
        while (idx < retry) and (rb != data):
            self.wr_ext(chip_id, start_addr, data)
            rb = self.rd_ext(chip_id, start_addr, len(data))
            idx += 1
            time.sleep(0.0001)
        return rb, idx

    def reset(self):
        _log.spi(f"spi{self.cs} reset")
        self.spi.Cloudchaser_drv.spi_reset()

    def soft_reset(self):
        _log.spi(f"spi{self.cs} soft_reset chip={self.chip_id}")
        self.spi.Cloudchaser_drv.spi_soft_reset(self.chip_id)

    def init(self, speed):
        _log.spi(f"spi{self.cs} init speed={speed}")
        self.spi.Cloudchaser_drv.spi_init(speed)

    def beam_up(self):
        _log.spi(f"spi{self.cs} beam_up")
        self.spi.Cloudchaser_drv.spi_beam_upd()

    def close(self):
        _log.spi(f"spi{self.cs} close")
        self.spi.Cloudchaser_drv.spi_close()