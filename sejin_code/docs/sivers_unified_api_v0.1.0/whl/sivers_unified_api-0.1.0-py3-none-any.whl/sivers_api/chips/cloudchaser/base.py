try:
    from ...BFIC import Sivers_BFIC
    from ...enums import BFIC_TYPE, BFIC
    from ...log import SiversLogger
    from .blocks.path import PathSpec
    from .blocks.beam import BeamTable
    from .blocks.adc import ADC
    from .blocks.bias import Bias
    from .blocks.center import Center
    from .blocks.quad import Quad
except ImportError:
    from sivers_api.BFIC import Sivers_BFIC
    from sivers_api.enums import BFIC_TYPE, BFIC
    from sivers_api.log import SiversLogger
    from sivers_api.chips.cloudchaser.blocks.path import PathSpec
    from sivers_api.chips.cloudchaser.blocks.beam import BeamTable
    from sivers_api.chips.cloudchaser.blocks.adc import ADC
    from sivers_api.chips.cloudchaser.blocks.bias import Bias
    from sivers_api.chips.cloudchaser.blocks.center import Center
    from sivers_api.chips.cloudchaser.blocks.quad import Quad

_log = SiversLogger()


class Cloudchaser(Sivers_BFIC):
    def __init__(self, bfic: BFIC, bfic_type: BFIC_TYPE, chip_id: int, quiet: bool, spi_obj):
        super().__init__(bfic=bfic, bfic_type=bfic_type, chip_id=chip_id, quiet=quiet, spi_obj=spi_obj)
        self.beam_table = BeamTable(self.spi, self.chip_id)
        self.adc = ADC(self._regs)
        self.bias = Bias(self._regs)
        self.center = Center(self._regs)
        self.quad: list[Quad] = [Quad(i, self._regs) for i in range(4)]
        self.path = PathSpec(self, self.bfic_type)

    def reset(self):
        super().reset()
        self.path.clear()

    def load_efuse(self):
        revision = self._parse_efuse_revision(self.fields.rd("uid_high"))
        self._execute_efuse_instructions(revision)

    def _parse_efuse_revision(self, uid_h: int) -> str:
        uid_h = int(uid_h)
        if ((uid_h >> 13) & 0x7) == 0x0:
            _log.debug(f"Parsed eFuse revision 'rev_1' from uid_high={uid_h:#x} on {self.bfic.value} chip_id={self.chip_id}")
            return "rev_1"
        _log.warning(f"Unknown revision for UID_H {uid_h:#x} on {self.bfic.value} chip_id={self.chip_id}. Unable to determine eFuse instructions.")
        return "unknown"
