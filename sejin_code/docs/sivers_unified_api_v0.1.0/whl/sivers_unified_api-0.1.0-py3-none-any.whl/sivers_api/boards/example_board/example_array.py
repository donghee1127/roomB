try:
    from ...chips import Stampede, Blueway
    from ...BFIC import Sivers_BFIC
    from ...enums import BFIC_TYPE
    from ...spi.fake_spi import Fake_SPI
except ImportError:
    from sivers_api.chips import Stampede, Blueway
    from sivers_api.BFIC import Sivers_BFIC
    from sivers_api.enums import BFIC_TYPE
    from sivers_api.spi.fake_spi import Fake_SPI

class Example_Array:
    def __init__(self, x=20, y=20, array_type=BFIC_TYPE.TX):
        self._array = [[None for _ in range(x)] for _ in range(y)]
        self._array_type = array_type
        self.x = x
        self.y = y
        self.ic_type = Stampede if array_type == BFIC_TYPE.TX else Blueway
        ids_per_object = 40
        counter = 0
        resets = 0
        spi_obj = Fake_SPI(csn=resets)
        for idy in range(self.shape()[1]):
            for idx in range(self.shape()[0]):
                if counter >= ids_per_object:
                    counter = 0
                    resets += 1
                    spi_obj = Fake_SPI(csn=resets)
                self.add_chip(idx, idy, self.ic_type, chip_id=counter, spi_obj=spi_obj)
                counter += 1

    def __getitem__(self, idx):
        return self._array[idx]

    def __len__(self):
        x, y = self.shape()
        return x * y

    def __iter__(self):
        for y, row in enumerate(self._array):
            for x, chip in enumerate(row):
                yield (x, y, chip)

    def shape(self):
        return (self.x, self.y)

    def add_chip(self, x: int, y: int, chip: Sivers_BFIC, **kwargs):
        self._array[y][x] = chip(**kwargs)