try:
    from ...spi.spi_ftdi import SPI_FTDI
    from ...spi.spi_spec import SPIReq
except ImportError:
    from sivers_api.spi.spi_ftdi import SPI_FTDI
    from sivers_api.spi.spi_spec import SPIReq
import numpy as np
import pandas as pd
from pathlib import Path
from typing import Union

def build_beam_table() -> dict[str:int]:
    return np.zeros((1024, 4), dtype=np.uint16)


class BeamTable:
    beam_field = { # field name : (start_bit, bit_width)
        "attenuator_setting"    : (0,  6),
        "phase_shifter_setting" : (7,  7),
        "Phase_loss_cal"        : (14, 2),
    }
    _table_size = (1024, 4) # 1024 beams, 4 quads per beam
    
    def __init__(self, spi_obj:SPIReq, chip_id:int):
        self.spi = spi_obj
        self.chip_id = chip_id
        self.table = build_beam_table()
        self.tmp_table = np.zeros_like(self.table)
    
    def init(self, beambook:Union[Path, str, None]=None, write_calibration:bool=False):
        print("BEAM TABLE FUNCTIONALLY NOT FULLY IMPLEMENTED/TESTED YET, USE WITH CAUTION") #TODO Remove this warning once functionality is fully implemented and tested
        print("Initializing beam table...")
        self.read_table()
        print("Beam table read from device.")
        if beambook is not None:
            print(f"Loading beam table from {beambook}...")
            self.load_table_csv(beambook, write_calibration)
            print("Writing beam table to device...")
            self.commit_table()
        else:
            print("No beambook provided, skipping writing beam table.")
        print("Beam table initialized.")

    def _get_field_mask(self, fields:list[str]) -> int:
        mask = 0
        for field in fields:
            if field not in self.beam_field:
                raise ValueError(f"Invalid field name: {field}")
            start_bit, bit_width = self.beam_field[field]
            mask |= ((1 << bit_width) - 1) << start_bit
        return mask
    
    
    def zero_table(self, commit:bool=True):
        self.table = np.zeros_like(self.table)
        self.tmp_table = np.zeros_like(self.tmp_table)
        if commit:
            print("Zeroing beam table on device...")
            self.commit_table()
    
    def load_table_csv(self, filepath:Union[Path, str], write_calibration:bool=False):
        """
        Example CSV format:
        
        beam, quad, attenuator_setting, phase_shifter_setting, phase_loss_cal,
        0, 0, 0, 0, 0,
        0, 1, 0, 0, 0,
        0, 2, 0, 0, 0,
        0, 3, 0, 0, 0,
        ....
        1023, 0, 0, 0, 0,
        1023, 1, 0, 0, 0,
        1023, 2, 0, 0, 0,
        1023, 3, 0, 0, 0,
        """
        if isinstance(filepath, str):
            filepath = Path(filepath)
        if not filepath.exists():
            raise FileNotFoundError(f"CSV file not found: {filepath}")
        print(f"Loading beam table from {filepath}...")
        df = pd.read_csv(filepath.resolve())
        for _, row in df.iterrows():
            beam = int(row['beam'])
            quad = int(row['quad'])
            for field, (start_bit, bit_width) in self.beam_field.items():
                if field == "Phase_loss_cal":
                    if not write_calibration:
                        continue
                    if pd.isna(row[field]) or row[field] in ["", "None", "0x0", "none",None]:
                        value = 0
                    try:
                        value = int(row[field])
                    except ValueError:
                        value = 0
                else:
                    value = int(row[field])
                
                self.tmp_table[beam, quad] |= self._get_field_mask([field]) & (value << start_bit)
        
        self.update_table(write_calibration)
        print("Beam table loaded from CSV.")
    
    def update_table(self, start_beam:int=0x0000, stop_beam:int=0x03ff, write_calibration:bool=False):
        length = stop_beam - start_beam + 1
        if length > self._table_size[0]:
            raise ValueError(f"Length exceeds table size: {length} > {self._table_size[0]}")
        for beam in range(start_beam, stop_beam+1):
            for quad in range(self._table_size[1]):
                self.table[beam, quad] = self.tmp_table[beam, quad] if write_calibration else (self.table[beam, quad] & self._get_field_mask(["Phase_loss_cal"])) | (self.tmp_table[beam, quad] & self._get_field_mask(["attenuator_setting", "phase_shifter_setting"]))
        self.tmp_table = np.zeros_like(self.table)
    
    def commit_table(self, start_beam:int=0x0000, stop_beam:int=0x03ff):
        length = stop_beam - start_beam +1
        if length > self._table_size[0]:
            raise ValueError(f"Length exceeds table size: {length} > {self._table_size[0]}")
        if start_beam > 0x03ff:
            raise ValueError(f"Invalid start beam: {start_beam}")
        if start_beam > stop_beam:
            raise ValueError(f"Start beam cannot be greater than stop beam: {start_beam} > {stop_beam}")
        if stop_beam > 0x03ff:
            raise ValueError(f"Invalid stop beam: {stop_beam}")

        self.spi.wr_ext(self.chip_id, start_beam, self.table[start_beam:stop_beam+1].flatten().tolist())
    
    def read_table(self, start_beam:int=0x0000, stop_beam:int=0x03ff) -> np.ndarray:
        length = stop_beam - start_beam + 1
        if length > self._table_size[0]:
            raise ValueError(f"Length exceeds table size: {length} > {self._table_size[0]}")
        if start_beam > 0x03ff:
            raise ValueError(f"Invalid start beam: {start_beam}")
        if start_beam > stop_beam:
            raise ValueError(f"Start beam cannot be greater than stop beam: {start_beam} > {stop_beam}")
        if stop_beam > 0x03ff:
            raise ValueError(f"Invalid stop beam: {stop_beam}")
        self.tmp_table = np.array(self.spi.rd_ext(self.chip_id, start_beam, length*4), dtype=np.uint16).reshape((int(length), 4))
        self.update_table(start_beam=start_beam, stop_beam=stop_beam, write_calibration=True)
        return self.table
