try:
    from .spi_spec import SPIReq
    from ..enums import BFIC
except ImportError:
    from sivers_api.spi.spi_spec import SPIReq
    from sivers_api.enums import BFIC

class Fake_SPI(SPIReq):
    compatible_bfic = [BFIC.STAMPEDE, BFIC.BLUEWAY]

    def __init__(self, csn=0, quiet=False, bfic: BFIC = None):
        super().__init__(csn, quiet, bfic)
        self.regs = {a: 0 for a in range(0x0000, 0x1203+1)}
    
    def wr(self, chip_id:int, addr:int, data:int):
        print('spi{0}_write {1} {2} {3}'.format(self.cs, chip_id, f"0x{addr:04X}", f"0x{data:04X}"))
        self.regs[addr] = data
    
    def rd(self, chip_id:int, addr:int) -> int:
        print('spi{0}_read {1} {2}'.format(self.cs, chip_id, f"0x{addr:04X}"))
        return self.regs[addr]
    
    def wr_ext(self, chip_id:int, start_addr:int, data:list[int]):
        print('spi{0}_write_extended {1} {2} {3}'.format(self.cs, chip_id, f"0x{start_addr:04X}", [f"0x{d:04X}" for d in data]))
        for idx, data in enumerate(data):
            self.regs[start_addr+idx] = data

    def rd_ext(self, chip_id:int, start_addr:int, length:int) -> int:
        print('spi{0}_read_extended {1} {2} {3}'.format(self.cs, chip_id, f"0x{start_addr:04X}", length))
        return [self.regs[start_addr+i] for i in range(0, length)]

    def adc_capture(self, chip_id:int):
        print('spi{0}_adc_capture {1}'.format(self.cs, chip_id))

    def reset(self):
        print('spi{0}_reset'.format(self.cs))

    def verify_wr(self, chip_id:int, addr:int, data:int, retry:int=10):
        self.wr(chip_id, addr, data)
        rd = self.rd(chip_id, addr)
        return rd, 1
    
    def verify_wr_ext(self, chip_id:int, start_addr:int, data:list[int], retry:int = 10):
        self.wr_ext(chip_id, start_addr, data)
        ret = self.rd_ext(chip_id, start_addr, len(data))
        return ret, 1
        
    def soft_reset(self, chip_id:int):
        print('spi{0}_soft_reset {1}'.format(self.cs, chip_id))
    
    def init(self, speed):
        print('spi{0}_init {1}'.format(self.cs, speed))
    
    def beam_up(self):
        print('spi{0}_beam_upd'.format(self.cs))
    
    def close(self):
        print('spi{0}_close'.format(self.cs))
