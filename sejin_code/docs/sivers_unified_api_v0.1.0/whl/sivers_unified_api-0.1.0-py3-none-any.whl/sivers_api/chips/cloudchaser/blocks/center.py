try:
    from ....regs import Regs
    from ....enums import Beam, BFIC
except ImportError:
    from sivers_api.regs import Regs
    from sivers_api.enums import Beam, BFIC

class Center:
    def __init__(self, regs: Regs):
        self.regs = regs

    def _ac(self) -> bool:
        return self.regs.regs.get_auto_commit()

    def enable(self, beam: Beam=None):
        if beam == Beam.B0:
            b_idx = 0
        elif beam == Beam.B1:
            b_idx = 1
        elif beam is None:
            b_idx = None

        if b_idx is None:
            for i in range(2):
                if self.regs.bfic == BFIC.STAMPEDE:
                    self.regs.fields[f"beam{i}_pwrdn"] = 0x1
                    self.regs.fields[f"dist_b{i}_st1_en"] = 0xf
                elif self.regs.bfic == BFIC.BLUEWAY:
                    self.regs.fields[f"beam{i}_pwrdn"] = 0x4
                    self.regs.fields[f"dist_b{i}_st1_en"] = 0x3
        else:
            if self.regs.bfic == BFIC.STAMPEDE:
                self.regs.fields[f"beam{b_idx}_pwrdn"] = 0x1
                self.regs.fields[f"dist_b{b_idx}_st1_en"] = 0xf
            elif self.regs.bfic == BFIC.BLUEWAY:
                self.regs.fields[f"beam{b_idx}_pwrdn"] = 0x4
                self.regs.fields[f"dist_b{b_idx}_st1_en"] = 0x3

        if self._ac():
            self.regs.commit()
    
    def disable(self, beam: Beam=None):
        if beam == Beam.B0:
            b_idx = 0
        elif beam == Beam.B1:
            b_idx = 1
        elif beam is None:
            b_idx = None

        if b_idx is None:
            # Disable all beams
            for i in range(2):
                self.regs.fields[f"beam{i}_pwrdn"] = 0
                self.regs.fields[f"dist_b{i}_st1_en"] = 0x0
        else:
            self.regs.fields[f"beam{b_idx}_pwrdn"] = 0
            self.regs.fields[f"dist_b{b_idx}_st1_en"] = 0x0
        
        if self._ac():
            self.regs.commit()
        